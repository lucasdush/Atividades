import './styles.css';
import * as yup from 'yup';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import api from '../../service/api';
import { toast } from 'react-toastify';

const esquemaDeCadastro = yup.object({
  nome: yup.string().required('O nome é obrigatório'),
  email: yup.string().email('Email inválido').required('O email é obrigatório'),
  senha: yup.string().min(6, 'A senha deve ter no mínimo 6 caracteres').required('A senha é obrigatória')
});

export default function CadastroPage() {

  const {
    register: registrarCampo,
    handleSubmit: lidarComEnvioDoFormulario,
    formState: { errors: errosDoFormulario, isSubmitting: estaEnviando },
    setError: definirErroNoCampo,
    reset: limparCamposDoFormulario
  } = useForm({
    resolver: yupResolver(esquemaDeCadastro),
    defaultValues: {
      nome: '',
      email: '',
      senha: '',
    }
  });

  async function enviarDados(dadosDoFormulario) {
    const dadosParaEnvio = {
      nome: dadosDoFormulario.nome,
      email: dadosDoFormulario.email,
      senha: dadosDoFormulario.senha,
    };

    try {
      const resposta = await api.post('/users', dadosParaEnvio);
      toast.success('Funcionário cadastrado com sucesso!');
      limparCamposDoFormulario();

    } catch (erro) {
      const codigoDeStatus = erro.response?.status;
      const mensagemDeErro =
        erro.response?.data?.message ||
        'Erro ao cadastrar funcionário. Tente novamente mais tarde.';

      if (codigoDeStatus === 400) {
        definirErroNoCampo('email', {
          type: 'server',
          message: mensagemDeErro
        });
      } else {
        toast.error(mensagemDeErro);
        console.error('Erro ao cadastrar funcionário:', erro);
      }
    }
  }

  return (
    <div className="cadastro-container">
      <h2>Cadastro de Funcionário</h2>

      <form noValidate onSubmit={lidarComEnvioDoFormulario(enviarDados)}>

        {/* Nome */}
        <div className="form-group">
          <label htmlFor="campo-nome">Nome:</label>
          <input
            type="text"
            id="campo-nome"
            placeholder="Ex.: Lucas Xavier"
            {...registrarCampo('nome')}
          />
          {errosDoFormulario.nome && (
            <span className="error-message">{errosDoFormulario.nome.message}</span>
          )}
        </div>

        {/* Email */}
        <div className="form-group">
          <label htmlFor="campo-email">Email:</label>
          <input
            type="email"
            id="campo-email"
            placeholder="Ex.: lucas@suaempresa.com"
            {...registrarCampo('email')}
          />
          {errosDoFormulario.email && (
            <span className="error-message">{errosDoFormulario.email.message}</span>
          )}
        </div>

        {/* Senha */}
        <div className="form-group">
          <label htmlFor="campo-senha">Senha:</label>
          <input
            type="password"
            id="campo-senha"
            placeholder="Digite sua senha"
            {...registrarCampo('senha')}
          />
          {errosDoFormulario.senha && (
            <span className="error-message">{errosDoFormulario.senha.message}</span>
          )}
        </div>

        {/* Botão */}
        <div className="form-group">
          <button type="submit" disabled={estaEnviando}>
            {estaEnviando ? 'Cadastrando...' : 'Cadastrar'}
          </button>
        </div>

      </form>
    </div>
  );
}
