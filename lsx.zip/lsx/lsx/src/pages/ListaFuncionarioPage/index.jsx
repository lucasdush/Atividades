import { use } from 'react';
import './styles.css';

export default function  ListaFuncionarioPage(){
    const [funcionarios, setFuncionarios] = useState([]);
    const [carregando, setCarregando] = useState(true);

    useEffect(() => {
        async function buscaFuncionario() {
            try{
                const resposta = await api.get('/usuarios');
                setFuncionarios(resposta.data);
            } catch (erro) {
                console.error('Erro ao buscar funcionários:', erro);
               const mensagemDoServidor = error.response?.data?.mensagem || 'Erro ao buscar funcionários. Tente novamente mais tarde.';
                toast.error(mensagemDoServidor);
            } finally {
                setCarregando(false);
            }
        }
        buscaFuncionario();
    }, []);
    if (carregando){
        return <div>Carregando funcionarios....</div>
    }
    
    return(
        <>
        
        </>
    )
}