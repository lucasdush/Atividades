import './styles.css';
import { Link } from 'react-router-dom';
export default function header(){
    return(
        <>
        <header className="header">
            <Link to="/">SENAI</Link>
            <nav>
                <Link to="/cadastro">Cadastrar Funcionarios</Link>
                <Link to="/funcionarios">Listar Funcionarios</Link>
            </nav>
        </header>
        </>
    );
}